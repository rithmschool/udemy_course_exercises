function getMostFollowers(...usernames) {}

function starWarsString(id) {}
