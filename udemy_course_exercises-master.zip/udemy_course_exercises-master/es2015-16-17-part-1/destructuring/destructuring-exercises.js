function displayStudentInfo(obj) {}

function printFullName({ first, last }) {}

function createStudent({ likesJavaScript = true, likesES2015 = true } = {}) {}

function reverseArray(arr) {}
