// spread
function smallestValue(...args) {}

// placeInMiddle([1,2,6,7],[3,4,5])
function placeInMiddle(arr, vals) {}

// rest
function joinArrays(...args) {}

// rest
function sumEvenArgs(...args) {}

// rest
function flip(fn, thisArg, ...outerArgs) {}

// rest + spread
function bind(fn, thisArg, ...outerArgs) {}
