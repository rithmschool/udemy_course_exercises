# Warbler Server Starter

The sever does token based authentication for signup and sign in

## Setup

The server is a NodeJS application that uses express and mongoDB.  To get setup:

* run: `npm install`
* Create a `.env` file. In the file, add

```js
SECRET_KEY=longRandomStringOfCharacters
```
__DO NOT CHECK IN THIS FILE__

* npm start

