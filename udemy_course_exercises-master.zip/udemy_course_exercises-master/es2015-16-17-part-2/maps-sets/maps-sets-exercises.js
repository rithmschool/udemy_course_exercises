// maps

class MessageBoard {}

// sets
function uniqueValues(arr) {}

function hasDuplicates(arr) {}

function countPairs(arr, num) {}
