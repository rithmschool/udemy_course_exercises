// Array.from
// Object.assign
// Number.isFinite

function copyObject(obj) {}

function checkIfFinite(num) {}

function areAllNumbersFinite(arr) {}

function convertArrayLikeObject(obj) {}

function displayEvenArguments() {}
