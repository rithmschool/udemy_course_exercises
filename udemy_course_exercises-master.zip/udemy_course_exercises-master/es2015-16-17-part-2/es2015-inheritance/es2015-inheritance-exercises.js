class Vehicle {}
