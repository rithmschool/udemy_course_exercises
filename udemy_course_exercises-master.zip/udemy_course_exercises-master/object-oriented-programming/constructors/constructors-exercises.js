// Create a constructor function for a Person, each person should have a firstName, lastName, favoriteColor and favoriteNumber.

// Write a method called multiplyFavoriteNumber that takes in a number and returns the product of the number and the Person's favorite number

// refactor
