// inherit 1 thing from another

function Vehicle(make, model, year) {}
